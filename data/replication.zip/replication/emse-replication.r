library(lavaan)	
library(ltm)
library(xtable)
library(semTools)
library(jtools)
library(interactions)
library(ggplot2)
library(dplyr)


## Confirmatory Factor Analysis (CFA)
model.cfa <- '
 desire        =~ num_want_learn_languages + num_want_learn_skills
 expertise     =~ num_knows_languages      + num_has_skills
 participation =~ num_meetings_attended    + has_chatroom_handle + num_challenges_solved 
 id            =~ ID1 + ID2 
 hc            =~ HC1 + HC2 + HC3
 js            =~ JS1 + JS2 + JS4
 engagement    =~ id  + hc
'

# HTMT ratios are not calculated for the second-order construct, so take engagement out of the CFA
# and perform a separate CFA for the purposes of calculating HTMT
model.htmt <- '
 desire        =~ num_want_learn_languages + num_want_learn_skills
 expertise     =~ num_knows_languages + num_has_skills
 participation =~ num_challenges_solved + num_meetings_attended + has_chatroom_handle
 id            =~ ID1 + ID2
 hc            =~ HC1 + HC2 + HC3
 js            =~ JS1 + JS2 + JS4
'

model.sem <- '
 # measurement model
 desire =~ num_want_learn_languages + num_want_learn_skills
 part   =~ num_challenges_solved    + num_meetings_attended + has_chatroom_handle
 id     =~ ID1 + ID2
 hc     =~ HC1 + HC2 + HC3
 js     =~ JS1 + JS2 + JS4
 engag  =~ id  + hc

 # structural model
 part   ~ desire         + age + ismale + tenure_s
 engag  ~ p*part         + age + ismale + tenure_s
 js     ~ j*engag + part + age + ismale + tenure_s  

 # indirect effect
 ind_js := p*j
'

# Read in the matrices and run the CFA and SEM.

CFA.NACOV2 <- as.matrix(read.csv("cfa-nacov.csv", header=F))
CFA.S2     <- as.matrix(read.csv("cfa-s.csv", header=T, row.names=1))
cfa.fit    <- cfa(model=model.cfa, NACOV=CFA.NACOV2, sample.cov=CFA.S2, sample.nobs=155, estimator="MLM")

summary(cfa.fit, standardized=T, fit.measures=T, ci=T)

HTMT.NACOV2 <- as.matrix(read.csv("htmt-nacov.csv", header=F))
HTMT.S2     <- as.matrix(read.csv("htmt-s.csv", header=T, row.names=1))
htmt.fit    <- cfa(model.htmt, NACOV=HTMT.NACOV2, sample.cov=HTMT.S2, sample.nobs=155, estimator="MLM")
summary(htmt.fit, standardized=T, fit.measures=T, ci=T)

reliability(htmt.fit)["avevar",]

# engagement is a second order construct, and reliability() doesn't know this, so calculate the 
# AVE manually. Just the average of the squared loadings. 
loading.id   <- parameterEstimates(cfa.fit, standardized=TRUE) %>% filter(op == "=~", rhs=="id") %>% select(std.all)
loading.hc   <- parameterEstimates(cfa.fit, standardized=TRUE) %>% filter(op == "=~", rhs=="hc") %>% select(std.all)
# Calculate AVE of engagement; average of squared loadings
eng.ave      <- ((loading.id^2) + (loading.hc^2)) / 2
eng.ave
# and take squared root (for Fornell-Larcker)
eng.ave.sqrt <- sqrt(eng.ave)
eng.ave.sqrt 


SEM.NACOV2 <- as.matrix(read.csv("sem-nacov.csv", header=F))
SEM.S2     <- as.matrix(read.csv("sem-s.csv", header=T, row.names=1))
sem.fit    <- sem(model=model.sem, NACOV=SEM.NACOV2, sample.cov=SEM.S2, sample.nobs=155, estimator="MLM")

# Create a data frame and add the control variables to it.
fscores <- read.csv("factorscores.csv", header=T)


# Define model for Hypothesis 2 (the interaction)
# An interaction is modeled by including the moderator AND the product term of the moderator and the moderated criterion variable.
model.h2.sem <- 'participation ~ desire + expertise + expertise:desire + age + tenure_s + ismale'
fit.h2       <- sem(model.h2.sem, estimator="MLM", data=fscores)
summary(fit.h2, fit.measures=T,standardized=T, ci=T)

# Alternatively, and perhaps easier (but no std coeffs), use the lm() function.
model.h2.lm <- lm(participation ~ desire * expertise + desire:expertise + age + tenure_s + ismale, data=fscores)
summ(model.h2.lm)

# Standard interaction plot (+/- 1 standard deviation)
interact_plot(model.h2.lm, pred=desire, modx=expertise, centered="none")  

# Johnson-Neyman plot
jnplot <- johnson_neyman(model.h2.lm, pred="desire", modx="expertise", vmat = NULL, alpha = 0.05,
                         plot = TRUE, control.fdr = FALSE, line.thickness = 0.5, title = "")

jnplot$plot + ylab("Slope of Desire to learn") + xlab("Developer expertise")  + 
  theme(panel.background = element_rect(fill = "white", size = 0.5, linetype = "solid"))


## R2 values
r <- inspect(sem.fit, "r2")
rdf <- data.frame(r)
rdf["js","r"]
#rdf["part","r"] # this does not include the moderator - see below.
rdf["engag","r"]

# R2 values of the interaction model (Hypothesis 2)
r.h2 <- inspect(fit.h2, "r2")
r.h2.df <- data.frame(r.h2)
r.h2.df


