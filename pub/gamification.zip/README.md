This is the replication package for the paper "Adopt a Monster"

Per agreement with the XCorp, the organization that facilitated the data collection, we cannot make the full data set available. To run the model nevertheless, this package provides the necessary matrices that can be loaded (and which are derived from the data set). The following matrices are provided:

 S.csv		the covariance matrix
 NACOV.csv	necessary because the estimator is not standard ML, but MLM
 h2-fscores.csv	factor scores for the 3 latent variables used for hypothesis 2

The script replication.r loads theses files and invokes the sem() function from the lavaan package, which is assumed to be installed. If not, run this script:

 install.packages("lavaan")

At the time of writing [July 2020], this will install version 0.6.6. This replication package is tested. If despite that there are any problems, please contact the editor who can contact us on your behalf.